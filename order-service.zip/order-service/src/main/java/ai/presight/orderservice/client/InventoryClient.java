package ai.presight.orderservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import ai.presight.orderservice.config.FeignConfig;

@FeignClient(
        name = "inventory-service",
        path = "/api/v1/inventory",
        configuration = FeignConfig.class
)
public interface InventoryClient {

	@GetMapping("/check")
    boolean isInStock(@RequestParam("sku") String skuCode, @RequestParam("qty") int qty);

    @PostMapping("/deduct")
    void deductStock(@RequestParam("skuCode") String skuCode, @RequestParam("qty") int qty);
}
 